import React from 'react'
import HeroSection from '../components/HeroSection.jsx'

function Home() {
  return (
    <>
    <HeroSection/>
  
    </>
  )
}

export default Home
